
public class Student 
{
	public String firstName;
	public String lastName;
	public String school;
	public Double gpa; 

	Student (String fName, String lName, String school, Double gpa)
	{
	 
	 this.firstName = fName;
	 
	 this.lastName = lName;
	 
	 this.school = school;
	 
	 this.gpa = gpa;
	 
	}

	public String toString()
	{
	 
	 return  this.firstName + " " + this.lastName + " " +   this.school + " " +   this.gpa + " ";
	 
	}
}
