
public class GraduateStudent extends Student
{
	public Double gradGPA;
	public String gradSchool;
	public Integer gradGraduationYear;

	GraduateStudent (String fName, String lName, String ugschool, Double ugGPA, String gradSchool, Double gradGPA, Integer gradGraduationYear)
	{
	 
	 
	 super (fName, lName, ugschool, ugGPA);
	 
	 this.gradGPA = gradGPA;
	 
	 this.gradSchool = gradSchool;
	 
	 this.gradGraduationYear = gradGraduationYear;
	 
	}

	public void setUGGPA (Double newGPA)
	{
	 
	 super.gpa = newGPA;
	 
	}

	public void setGPA (Double newGPA)
	{
	 
	 this.gradGPA = newGPA;
	 
	}

	public String toString()
	{
	 
	 String studentInfo = super.toString();
	 
	 return 
	   studentInfo + " " +
	   
	   this.gradSchool + " " + 
	   
	   this.gradGPA + " " + 
	   
	   this.gradGraduationYear;
	 
	}
}
