
public class TestInheritance 
{

	public static void main(String[] args) 
	{
		 GraduateStudent gs1 = new GraduateStudent ("John", "Smith", "NJIT", 3.5, "Monmouth U", 0.0, 2025);
		 gs1.setGPA(3.6);
		 System.out.println(gs1.toString());
		 
		 GraduateStudent gs2 = new GraduateStudent ("Pearson", "Charles", "Stevens", 3.8, "Rowan", 0.0, 2026);
		 gs2.setGPA(3.2);
		 System.out.println(gs2.toString());
		 
		 GraduateStudent gs3 = new GraduateStudent ("Miller", "Janet", "Rutgers", 3.1, "Stevens", 0.0, 2024);
		 gs3.setGPA(3.4);
		 System.out.println(gs3.toString());
		 
		 GraduateStudent gs4 = new GraduateStudent ("Micheal", "James", "Monmouth U", 3.98, "Stevens", 0.0, 2027);
		 gs4.setGPA(3.8);
		 System.out.println(gs4.toString());

	}

}
